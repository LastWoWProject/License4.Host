<?php

if( !defined("WHMCS") ) 
{
    exit( "This file cannot be accessed directly" );
}

$token = "YOUR_TOKEN";
echo $token;
?>